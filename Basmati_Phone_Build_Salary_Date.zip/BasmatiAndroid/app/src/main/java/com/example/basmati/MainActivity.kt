package com.example.basmati

import android.app.*
import android.os.Bundle
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class DB(ctx: android.content.Context) : SQLiteOpenHelper(ctx, "basmati.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE attendance(date TEXT PRIMARY KEY, cin TEXT, cout TEXT, treatment TEXT NOT NULL DEFAULT 'PENDING', note TEXT)""")
        db.execSQL("""CREATE TABLE permissions(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, kind TEXT, minutes INTEGER, treatment TEXT, note TEXT)""")
        db.execSQL("""CREATE TABLE leaves(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, days REAL, note TEXT)""")
        db.execSQL("""CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT)""")\n        db.execSQL("""CREATE TABLE salary_history(start_date TEXT PRIMARY KEY, salary REAL NOT NULL)""")
        val defaults = mapOf("salary" to "0", "annual" to "30", "start" to "09:00", "end" to "18:00",
            "breakStart" to "13:00", "breakEnd" to "14:00", "manualDeduct" to "0", "manualAdd" to "0")
        defaults.forEach { (k,v) -> db.execSQL("INSERT INTO settings(k,v) VALUES(?,?)", arrayOf(k,v)) }\n        db.execSQL("INSERT INTO salary_history(start_date,salary) VALUES(?,?)", arrayOf("0001-01-01", 0))
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS salary_history(start_date TEXT PRIMARY KEY, salary REAL NOT NULL)")
            db.execSQL("INSERT INTO salary_history(start_date,salary) VALUES(?,?)",
                arrayOf("0001-01-01", settingFromDb(db, "salary", "0").toDoubleOrNull() ?: 0.0))
        }
    }
    private fun settingFromDb(db: SQLiteDatabase, key: String, fallback: String): String {
        db.rawQuery("SELECT v FROM settings WHERE k=?", arrayOf(key)).use {
            return if (it.moveToFirst()) it.getString(0) else fallback
        }
    }
    fun salaryForDate(date:String):Double {
        readableDatabase.rawQuery("SELECT salary FROM salary_history WHERE start_date<=? ORDER BY start_date DESC LIMIT 1", arrayOf(date)).use {
            if (it.moveToFirst()) return it.getDouble(0)
        }
        return setting("salary","0").toDoubleOrNull() ?: 0.0
    }
    fun setSalaryFromDate(date:String, salary:Double) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO salary_history(start_date,salary) VALUES(?,?)", arrayOf(date,salary))
        set("salary", salary.toString())
    }
    fun setting(k:String, def:String="0"):String {
        readableDatabase.rawQuery("SELECT v FROM settings WHERE k=?", arrayOf(k)).use { if(it.moveToFirst()) return it.getString(0) }
        return def
    }
    fun set(k:String,v:String) { val c=ContentValues().apply{put("k",k);put("v",v)}; writableDatabase.insertWithOnConflict("settings",null,c,SQLiteDatabase.CONFLICT_REPLACE) }
    fun todayRow(date:String):android.database.Cursor = readableDatabase.rawQuery("SELECT cin,cout,treatment,note FROM attendance WHERE date=?", arrayOf(date))
    fun attendanceRows():android.database.Cursor = readableDatabase.rawQuery("SELECT date,cin,cout,treatment FROM attendance ORDER BY date DESC", null)
    fun saveAttendance(date:String, cin:String?, cout:String?, treatment:String, note:String="") {
        val c=ContentValues().apply { put("date",date); if(cin!=null)put("cin",cin);if(cout!=null)put("cout",cout);put("treatment",treatment);put("note",note) }
        writableDatabase.insertWithOnConflict("attendance",null,c,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun addPermission(date:String,kind:String,minutes:Int,treatment:String,note:String) {
        val c=ContentValues().apply{put("date",date);put("kind",kind);put("minutes",minutes);put("treatment",treatment);put("note",note)}
        writableDatabase.insert("permissions",null,c)
    }
    fun addLeave(date:String,days:Double,note:String) {
        val c=ContentValues().apply{put("date",date);put("days",days);put("note",note)}
        writableDatabase.insert("leaves",null,c)
    }
    fun usedLeaves():Double { readableDatabase.rawQuery("SELECT COALESCE(SUM(days),0) FROM leaves",null).use{it.moveToFirst();return it.getDouble(0)} }
    fun permissionsLate(treatment:String):Int {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(minutes),0) FROM permissions WHERE kind='إذن تأخير' AND treatment=?",arrayOf(treatment)).use{it.moveToFirst();return it.getInt(0)}
    }
    fun attendanceLate(treatment:String):Int {
        val start=toMin(setting("start","09:00"))
        readableDatabase.rawQuery("SELECT cin FROM attendance WHERE treatment=?",arrayOf(treatment)).use { c ->
            var sum=0
            while(c.moveToNext()) { val t=c.getString(0) ?: continue; sum += (toMin(t)-start).coerceAtLeast(0) }
            return sum
        }
    }
    fun totalLate(treatment:String)=attendanceLate(treatment)+permissionsLate(treatment)
    fun extraEquivalentMinutes():Double {
        var total=0.0
        attendanceRows().use { c -> while(c.moveToNext()) {
            val cin=c.getString(1) ?: continue; val cout=c.getString(2) ?: continue
            var a=toMin(cin); var b=toMin(cout); if(b<a)b+=1440
            total += (minOf(b,1200)-maxOf(a,1080)).coerceAtLeast(0)*1.5
            total += (b-maxOf(a,1200)).coerceAtLeast(0)*2.0
        }}
        return total
    }
    fun recordsCsv():String {
        val out=StringBuilder("التاريخ,الحضور,الانصراف,معالجة التأخير\\n")
        attendanceRows().use{c->while(c.moveToNext()){out.append("${c.getString(0)},${c.getString(1)},${c.getString(2)},${c.getString(3)}\\n")}}
        return out.toString()
    }
}
fun toMin(s:String):Int { val p=s.split(":"); return p[0].toInt()*60+p[1].toInt() }
fun nowDate()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
fun nowTime()=SimpleDateFormat("HH:mm",Locale.US).format(Date())

class MainActivity : Activity() {
    private lateinit var db:DB
    private lateinit var root:LinearLayout
    private lateinit var status:TextView
    private lateinit var summary:TextView
    private var treatment="PENDING"
    private fun txt(s:String,size:Float=16f,bold:Boolean=false):TextView = TextView(this).apply {
        text=s;textSize=size;setTextColor(0xFF20312D.toInt()); if(bold)setTypeface(null,Typeface.BOLD)
        gravity=Gravity.RIGHT
        setPadding(4,8,4,8)
    }
    private fun button(s:String, action:()->Unit):Button=Button(this).apply {
        text=s; setOnClickListener{action()}
    }
    private fun field(hint:String,value:String=""):EditText=EditText(this).apply {
        this.hint=hint;setText(value);textSize=16f;gravity=Gravity.RIGHT
    }
    private fun section(title:String):LinearLayout {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,10,14,10);setBackgroundColor(0xFFF1F5F3.toInt())}
        box.addView(txt(title,18f,true)); val p=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,4,0,4)}
        box.addView(p);root.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,8,0,8)})
        return p
    }
    private fun addRow(parent:LinearLayout,vararg views:View){val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};views.forEach{row.addView(it,LinearLayout.LayoutParams(0,-2,1f))};parent.addView(row)}
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); db=DB(this)
        window.statusBarColor=0xFFF4F7F6.toInt(); window.decorView.layoutDirection=View.LAYOUT_DIRECTION_RTL
        val scroll=ScrollView(this);root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,12,16,24);setBackgroundColor(0xFFFFFFFF.toInt())}
        scroll.addView(root);setContentView(scroll); buildUI()
    }
    private fun buildUI(){
        root.addView(txt("بصمتي",26f,true));root.addView(txt("إدارة الحضور والانصراف والراتب • يعمل دون إنترنت",13f))
        val clock=txt("",20f,true);root.addView(clock);clock.text=nowDate()+"  |  "+nowTime()
        val s=section("بصمة اليوم")
        val treatmentSpinner=Spinner(this)
        val labels=listOf("غير مستثنى – بانتظار القرار","مستثنى","خصم من الإجازة","خصم من الراتب")
        treatmentSpinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,labels)
        treatmentSpinner.setSelection(when(getTodayTreatment()){ "EXEMPT"->1;"LEAVE"->2;"SALARY"->3;else->0 })
        treatmentSpinner.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p:AdapterView<*>?){}
            override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){ treatment=listOf("PENDING","EXEMPT","LEAVE","SALARY")[pos] }
        }
        s.addView(txt("طريقة معالجة تأخير اليوم"));s.addView(treatmentSpinner)
        addRow(s,button("🟢 تسجيل الحضور"){checkIn()},button("🔴 تسجيل الانصراف"){checkOut()})
        status=txt("",14f,true);s.addView(status)
        summary=txt("",14f);s.addView(summary)
        val p=section("الأذونات")
        p.addView(button("إضافة إذن تأخير أو إذن انصراف"){permissionDialog()})
        val l=section("الإجازات السنوية")
        l.addView(txt("الرصيد السنوي: ${db.setting("annual","30")} يوم • المستخدم: ${db.usedLeaves()} يوم"))
        l.addView(button("تسجيل إجازة مستخدمة"){leaveDialog()})
        val sal=section("الراتب والتقارير")
        sal.addView(txt("الراتب الشهري الحالي: ${db.setting("salary","0")} ريال يمني (يسري التعديل من تاريخ إدخاله)"))
        sal.addView(button("إعداد الراتب والخصومات والإضافات"){salaryDialog()})
        sal.addView(button("عرض ملخص الشهر الحالي"){monthlyReport()})
        sal.addView(button("تصدير سجل الحضور CSV"){shareCsv()})
        val settings=section("إعدادات الدوام")
        settings.addView(txt("الدوام ${db.setting("start","09:00")} – ${db.setting("end","18:00")} • الاستراحة ${db.setting("breakStart","13:00")} – ${db.setting("breakEnd","14:00")} (محسوبة ضمن الدوام)"))
        settings.addView(button("تعديل أوقات الدوام"){settingsDialog()})
        settings.addView(txt("حساب الإضافي: 6–8 مساءً × 1.5، وبعد 8 مساءً × 2. قيمة الساعة = الراتب ÷ 30 ÷ 8.",13f))
        refresh()
    }
    private fun getTodayTreatment():String { db.todayRow(nowDate()).use{if(it.moveToFirst())return it.getString(2)?: "PENDING"};return "PENDING" }
    private fun checkIn(){
        val date=nowDate();var oldIn:String?=null;var oldOut:String?=null
        db.todayRow(date).use{if(it.moveToFirst()){oldIn=it.getString(0);oldOut=it.getString(1)}}
        if(oldIn!=null){toast("تم تسجيل الحضور مسبقًا");return}
        db.saveAttendance(date,nowTime(),oldOut,treatment);refresh();toast("تم تسجيل الحضور")
    }
    private fun checkOut(){
        val date=nowDate();var cin:String?=null
        db.todayRow(date).use{if(it.moveToFirst())cin=it.getString(0)}
        if(cin==null){toast("سجل الحضور أولًا");return}
        db.saveAttendance(date,cin,nowTime(),treatment);refresh();toast("تم تسجيل الانصراف")
    }
    private fun refresh(){
        val cin: String?; val cout:String?
        db.todayRow(nowDate()).use{if(it.moveToFirst()){cin=it.getString(0);cout=it.getString(1)}else{cin=null;cout=null}}
        status.text="حضور: ${cin?: "—"}     انصراف: ${cout?: "—"}"
        val late=if(cin==null)0 else (toMin(cin)-toMin(db.setting("start","09:00"))).coerceAtLeast(0)
        val extra=db.extraEquivalentMinutes()
        val salary=db.salaryForDate(nowDate())
        val dayRate=salary/30.0;val hour=dayRate/8.0
        val salaryLate=db.totalLate("SALARY")
        val leaveLate=db.totalLate("LEAVE")
        val salaryPenalty=penaltyDays(salaryLate)*dayRate
        val leavePenalty=penaltyDays(leaveLate)
        val used=db.usedLeaves()+leavePenalty
        val net=salary-salaryPenalty-(db.setting("manualDeduct","0").toDoubleOrNull()?:0.0)+(db.setting("manualAdd","0").toDoubleOrNull()?:0.0)+(extra/60.0*hour)
        summary.text="تأخير اليوم: $late دقيقة\\nالإضافي المكافئ المسجل: ${"%.1f".format(Locale.US,extra/60)} ساعة\\nالتأخير المحدد للخصم من الراتب: $salaryLate دقيقة • المعلق: ${db.totalLate("PENDING")} دقيقة\\nخصم التأخير من الإجازة: ${"%.2f".format(Locale.US,leavePenalty)} يوم\\nالإجازات المستخدمة: ${"%.2f".format(Locale.US,used)} من ${db.setting("annual","30")}\\nقيمة الساعة: ${"%.2f".format(Locale.US,hour)} ريال\\nخصم الراتب للتأخير: ${"%.2f".format(Locale.US,salaryPenalty)} ريال\\nصافي تقديري مع الإضافي: ${"%.2f".format(Locale.US,net)} ريال"
    }
    // كل 8 ساعات تأخير = 1.5 يوم. الجزء المتبقي يحسب بنسبة الساعة.
    private fun penaltyDays(minutes:Int):Double { val blocks=minutes/480;val rem=minutes%480;return blocks*1.5+(rem/480.0)*1.5 }
    private fun permissionDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,8,20,8)}
        val kind=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("إذن تأخير","إذن انصراف"))}
        val mins=field("المدة بالدقائق","0");val note=field("السبب أو الملاحظة")
        val treatmentSp=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("مستثنى","خصم من الإجازة","خصم من الراتب","غير مستثنى – معلق"))}
        box.addView(txt("نوع الإذن"));box.addView(kind);box.addView(txt("المدة بالدقائق"));box.addView(mins);box.addView(txt("المعالجة"));box.addView(treatmentSp);box.addView(note)
        AlertDialog.Builder(this).setTitle("إضافة إذن").setView(box).setPositiveButton("حفظ"){_,_->
            val n=mins.text.toString().toIntOrNull()?:0
            if(n>=0){val t=listOf("EXEMPT","LEAVE","SALARY","PENDING")[treatmentSp.selectedItemPosition];db.addPermission(nowDate(),kind.selectedItem.toString(),n,t,note.text.toString());refresh()}
        }.setNegativeButton("إلغاء",null).show()
    }
    private fun leaveDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,8,20,8)}
        val days=field("عدد الأيام","1");val note=field("ملاحظة")
        box.addView(days);box.addView(note)
        AlertDialog.Builder(this).setTitle("تسجيل إجازة").setView(box).setPositiveButton("حفظ"){_,_->
            val n=days.text.toString().toDoubleOrNull()?:0.0
            if(n>0)db.addLeave(nowDate(),n,note.text.toString());refresh()
        }.setNegativeButton("إلغاء",null).show()
    }
    private fun salaryDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,8,20,8)}
        val salary=field("الراتب الشهري","${db.setting("salary","0")}")
        val annual=field("رصيد الإجازة السنوي","${db.setting("annual","30")}")
        val deduct=field("خصومات أخرى بالريال","${db.setting("manualDeduct","0")}")
        val add=field("إضافات مالية أخرى بالريال","${db.setting("manualAdd","0")}")
        listOf(salary,annual,deduct,add).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("إعدادات الراتب (يسري التغيير من اليوم)").setView(box).setPositiveButton("حفظ"){_,_->
            db.setSalaryFromDate(nowDate(), salary.text.toString().toDoubleOrNull()?.coerceAtLeast(0.0)?: 0.0)
            db.set("annual",annual.text.toString().toDoubleOrNull()?.coerceAtLeast(0.0)?.toString()?: "30")
            db.set("manualDeduct",deduct.text.toString().toDoubleOrNull()?.coerceAtLeast(0.0)?.toString()?: "0")
            db.set("manualAdd",add.text.toString().toDoubleOrNull()?.coerceAtLeast(0.0)?.toString()?: "0");recreate()
        }.setNegativeButton("إلغاء",null).show()
    }
    private fun settingsDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,8,20,8)}
        val fields=listOf("start" to "بداية الدوام","end" to "نهاية الدوام","breakStart" to "بداية الاستراحة","breakEnd" to "نهاية الاستراحة")
        val edits=fields.map{(k,label)->val e=field(label,db.setting(k,when(k){"start"->"09:00";"end"->"18:00";"breakStart"->"13:00";else->"14:00"}));box.addView(e);k to e}
        AlertDialog.Builder(this).setTitle("أوقات الدوام (24 ساعة)").setView(box).setPositiveButton("حفظ"){_,_->edits.forEach{(k,e)->if(e.text.matches(Regex("\\d{2}:\\d{2}")))db.set(k,e.text.toString())};recreate()}.setNegativeButton("إلغاء",null).show()
    }
    private fun monthlyReport(){
        val month=nowDate().substring(0,7);var count=0;var late=0
        db.attendanceRows().use{c->while(c.moveToNext()){if(c.getString(0).startsWith(month)){count++;val t=c.getString(1);if(t!=null)late+=(toMin(t)-toMin(db.setting("start","09:00"))).coerceAtLeast(0)}}}
        AlertDialog.Builder(this).setTitle("تقرير $month").setMessage("أيام لها سجلات: $count\\nإجمالي تأخير الحضور: $late دقيقة\\nقيمة الساعة الأساسية: ${"%.2f".format(Locale.US,db.salaryForDate(nowDate())/240)} ريال\\n\\nراجع شاشة الراتب لمعرفة صافي الراتب التقديري.").setPositiveButton("حسنًا",null).show()
    }
    private fun shareCsv(){
        val intent=android.content.Intent(android.content.Intent.ACTION_SEND).apply{type="text/plain";putExtra(android.content.Intent.EXTRA_SUBJECT,"سجل بصمتي");putExtra(android.content.Intent.EXTRA_TEXT,db.recordsCsv())}
        try{startActivity(android.content.Intent.createChooser(intent,"مشاركة سجل بصمتي"))}catch(e:Exception){toast("تعذر فتح المشاركة")}
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
